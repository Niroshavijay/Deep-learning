#  Naive Bayes implementation on diabetes dataset
